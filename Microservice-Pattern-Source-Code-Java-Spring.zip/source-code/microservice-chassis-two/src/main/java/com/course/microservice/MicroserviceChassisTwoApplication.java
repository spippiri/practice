package com.course.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceChassisTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceChassisTwoApplication.class, args);
	}

}

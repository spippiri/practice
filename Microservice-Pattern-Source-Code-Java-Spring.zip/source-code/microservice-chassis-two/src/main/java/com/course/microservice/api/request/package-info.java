/**
 * HTTP request wrapper classes. Might contains classes that annotated as
 * <code>@RequestBody</code> (REST payload)
 */
package com.course.microservice.api.request;
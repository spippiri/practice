/**
 * Database adapter. Might contains Spring Data repository.
 */
package com.course.microservice.repository;
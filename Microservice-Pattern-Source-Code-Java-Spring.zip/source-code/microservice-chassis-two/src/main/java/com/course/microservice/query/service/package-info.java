/**
 * Query service (business logic flow controller). Query services can also has
 * individual business logic action. For example, to mask certain parts of
 * retrieved data before returning the query result.
 */
package com.course.microservice.query.service;
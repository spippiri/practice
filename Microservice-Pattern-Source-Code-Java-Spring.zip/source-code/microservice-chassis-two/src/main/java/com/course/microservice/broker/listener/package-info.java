/**
 * Message broker listener. Might class contains annotated with
 * <code>@KafkaListener</code>, <code>@KafkaHandler</code>,
 * <code>@RabbitListener</code>, <code>@RabbitHandler</code>
 */
package com.course.microservice.broker.listener;
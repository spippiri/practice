package com.course.microservice.config;

import org.springframework.context.annotation.Configuration;

/**
 * Dummy config.
 */
@Configuration
public class DummyConfig {

}

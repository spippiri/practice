/**
 * Database entity classes. Might contains classes annotated as
 * <code>@Entity</code>
 */
package com.course.microservice.entity;
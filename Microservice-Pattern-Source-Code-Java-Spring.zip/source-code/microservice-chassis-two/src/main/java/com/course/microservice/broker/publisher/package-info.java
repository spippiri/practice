/**
 * Message broker publisher. Might class contains that leverages
 * <code>KafkaTemplate</code>, <code>RabbitTemplate</code>
 */
package com.course.microservice.broker.publisher;
/**
 * Database entity classes. Might contains classes annotated as
 * <code>@Configuration</code>
 */
package com.course.microservice.config;
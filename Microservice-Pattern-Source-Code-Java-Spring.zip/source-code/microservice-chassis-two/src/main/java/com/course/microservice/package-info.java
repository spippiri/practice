/**
 * Root package.
 */
package com.course.microservice;
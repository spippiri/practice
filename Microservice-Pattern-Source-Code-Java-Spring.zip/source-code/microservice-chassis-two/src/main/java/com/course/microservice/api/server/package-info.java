/**
 * Inbound adapter, REST API controller. When using
 * <a href="https://spring.io/" target="_blank">Spring</a>, this package should
 * contains classes annotated with <code>@RestController</code>
 */
package com.course.microservice.api.server;
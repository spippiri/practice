/**
 * Wrapper class for message payload that sent to / received from message
 * broker.
 */
package com.course.microservice.broker.message;
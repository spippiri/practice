/**
 * HTTP response wrapper classes. Might contains <code>T</code> classes on
 * <code>ResponseEntity<T></code> (REST payload)
 */
package com.course.microservice.api.response;
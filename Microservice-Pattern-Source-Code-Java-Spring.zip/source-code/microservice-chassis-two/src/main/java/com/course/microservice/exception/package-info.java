/**
 * Custom exception classes.
 */
package com.course.microservice.exception;
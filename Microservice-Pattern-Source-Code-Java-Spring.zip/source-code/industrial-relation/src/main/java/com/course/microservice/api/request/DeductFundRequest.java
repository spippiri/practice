package com.course.microservice.api.request;

public class DeductFundRequest {

	private double deductAmount;

	public double getDeductAmount() {
		return deductAmount;
	}

	public void setDeductAmount(double deductAmount) {
		this.deductAmount = deductAmount;
	}

}

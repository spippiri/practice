package com.course.microservice.api.request;

public class AddFundRequest {

	private double addAmount;

	public double getAddAmount() {
		return addAmount;
	}

	public void setAddAmount(double addAmount) {
		this.addAmount = addAmount;
	}

}

package com.course.microservice.entity;

public enum PerformanceAppraisalStatus {

	APPROVAL_ERROR, APPROVAL_ON_PROGRESS, APPROVED, NEW

}
